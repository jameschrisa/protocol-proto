import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { FileText, Clock } from "lucide-react"
import { useState } from "react"
import { BusinessContinuityTable } from "../components/compliance/business-continuity-table"
import { businessContinuityAssets } from "../data/business-continuity-data"

export default function CompliancePage() {
  const [activeView, setActiveView] = useState<'continuity' | 'recovery'>('continuity')

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Compliance</h1>
      
      {/* Tabs Section */}
      <Card>
        <CardHeader className="flex flex-col items-stretch space-y-0 border-b p-0">
          <div className="flex flex-row items-center justify-between px-6 py-5">
            <div className="grid gap-1">
              <CardTitle>Compliance Management</CardTitle>
              <p className="text-sm text-muted-foreground">
                Manage regulatory compliance and recovery plans
              </p>
            </div>
          </div>
          <div className="flex">
            <button
              data-active={activeView === 'continuity'}
              className="relative z-30 flex flex-1 flex-col justify-center gap-1 border-t px-6 py-4 text-left data-[active=true]:bg-muted/50 sm:border-l sm:border-t-0 sm:px-8 sm:py-6"
              onClick={() => setActiveView('continuity')}
            >
              <span className="text-base font-semibold">
                Regulatory Compliance
              </span>
              <span className="text-sm text-muted-foreground">
                Manage compliance plans and procedures
              </span>
            </button>
            <button
              data-active={activeView === 'recovery'}
              className="relative z-30 flex flex-1 flex-col justify-center gap-1 border-t border-l px-6 py-4 text-left data-[active=true]:bg-muted/50 sm:border-l sm:border-t-0 sm:px-8 sm:py-6"
              onClick={() => setActiveView('recovery')}
            >
              <span className="text-base font-semibold">
                Recovery Planning
              </span>
              <span className="text-sm text-muted-foreground">
                Manage recovery plans and objectives
              </span>
            </button>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {activeView === 'continuity' ? (
            <div className="space-y-6">
              <div className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Impact Analysis</span>
                      <Button variant="outline" size="icon">
                        <FileText className="h-4 w-4" />
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">
                      Comprehensive analysis of compliance requirements and operational impact.
                    </p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Last Updated:</span>
                        <span>2024-03-15</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Last Reviewed:</span>
                        <span>2024-03-20</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Owner:</span>
                        <span>Sarah Johnson</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Response Procedures</span>
                      <Button variant="outline" size="icon">
                        <FileText className="h-4 w-4" />
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">
                      Detailed procedures for addressing compliance violations and incidents.
                    </p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Last Updated:</span>
                        <span>2024-02-28</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Last Reviewed:</span>
                        <span>2024-03-10</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Owner:</span>
                        <span>Michael Chen</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Documentation & Reporting</span>
                      <Button variant="outline" size="icon">
                        <FileText className="h-4 w-4" />
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">
                      Guidelines for maintaining compliance documentation and reporting requirements.
                    </p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Last Updated:</span>
                        <span>2024-03-01</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Last Reviewed:</span>
                        <span>2024-03-15</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Owner:</span>
                        <span>Emma Davis</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Compliance Assets Table */}
              <Card>
                <CardHeader>
                  <CardTitle>Compliance Assets</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Critical assets and processes requiring compliance monitoring
                  </p>
                </CardHeader>
                <CardContent>
                  <BusinessContinuityTable data={businessContinuityAssets} />
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Recovery Plan</span>
                    <Button variant="outline" size="icon">
                      <FileText className="h-4 w-4" />
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Last Updated:</span>
                      <span>2024-03-10</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Last Reviewed:</span>
                      <span>2024-03-25</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Owner:</span>
                      <span>David Wilson</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Response Time Target</span>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    The targeted duration for addressing and resolving compliance violations.
                  </p>
                  <div className="text-2xl font-bold text-center py-4">
                    4 Hours
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Reporting Deadline</span>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Maximum time allowed for reporting compliance incidents to authorities.
                  </p>
                  <div className="text-2xl font-bold text-center py-4">
                    24 Hours
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

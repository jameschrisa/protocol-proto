import { FlareMonitoringCharts } from "../components/compliance"
import { MaintenanceTable } from "../components/compliance/maintenance-table"
import { IncidentsTable } from "../components/compliance/incidents-table"
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card"
import { maintenanceData } from "../data/maintenance-data"
import { incidentsData } from "../data/incidents-data"
import { useState } from "react"

export default function FlareMonitoringPage() {
  const [activeView, setActiveView] = useState<'maintenance' | 'incidents'>('maintenance')

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Flare Monitoring</h1>
      
      {/* Charts */}
      <FlareMonitoringCharts />

      {/* Tabs Section */}
      <Card>
        <CardHeader className="flex flex-col items-stretch space-y-0 border-b p-0">
          <div className="flex flex-row items-center justify-between px-6 py-5">
            <div className="grid gap-1">
              <CardTitle>Flare System Management</CardTitle>
              <p className="text-sm text-muted-foreground">
                Monitor maintenance activities and system incidents
              </p>
            </div>
          </div>
          <div className="flex">
            <button
              data-active={activeView === 'maintenance'}
              className="relative z-30 flex flex-1 flex-col justify-center gap-1 border-t px-6 py-4 text-left data-[active=true]:bg-muted/50 sm:border-l sm:border-t-0 sm:px-8 sm:py-6"
              onClick={() => setActiveView('maintenance')}
            >
              <span className="text-base font-semibold">
                Maintenance Log
              </span>
              <span className="text-sm text-muted-foreground">
                Track scheduled and completed maintenance activities
              </span>
            </button>
            <button
              data-active={activeView === 'incidents'}
              className="relative z-30 flex flex-1 flex-col justify-center gap-1 border-t border-l px-6 py-4 text-left data-[active=true]:bg-muted/50 sm:border-l sm:border-t-0 sm:px-8 sm:py-6"
              onClick={() => setActiveView('incidents')}
            >
              <span className="text-base font-semibold">
                System Incidents
              </span>
              <span className="text-sm text-muted-foreground">
                Monitor and analyze system incidents and anomalies
              </span>
            </button>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {activeView === 'maintenance' ? (
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Maintenance Activities</h3>
              <MaintenanceTable data={maintenanceData} />
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Incident Reports</h3>
              <IncidentsTable data={incidentsData} />
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

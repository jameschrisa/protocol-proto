import { Database, HardDrive, Server, RefreshCw } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card"
import { Table } from "../components/ui/table"

export default function DataManagement() {
  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <Database className="h-8 w-8 text-blue-600" strokeWidth={1.5} />
        <h1 className="text-3xl font-bold">Data Management</h1>
      </div>

      {/* Storage Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <HardDrive className="h-5 w-5" />
              Storage Usage
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px] flex items-center justify-center text-muted-foreground">
              Storage usage chart will be displayed here
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" />
              Data Sources
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px] flex items-center justify-center text-muted-foreground">
              Connected data sources will be listed here
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <RefreshCw className="h-5 w-5" />
              Sync Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px] flex items-center justify-center text-muted-foreground">
              Data synchronization status will be shown here
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Data Sources Table */}
      <Card>
        <CardHeader>
          <CardTitle>Connected Data Sources</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border rounded-md">
            <Table>
              <thead>
                <tr>
                  <th className="px-4 py-2">Source Name</th>
                  <th className="px-4 py-2">Type</th>
                  <th className="px-4 py-2">Status</th>
                  <th className="px-4 py-2">Last Sync</th>
                  <th className="px-4 py-2">Size</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="px-4 py-2">Primary Database</td>
                  <td className="px-4 py-2">PostgreSQL</td>
                  <td className="px-4 py-2">Connected</td>
                  <td className="px-4 py-2">2 minutes ago</td>
                  <td className="px-4 py-2">1.2 TB</td>
                </tr>
                <tr>
                  <td className="px-4 py-2">Backup Storage</td>
                  <td className="px-4 py-2">S3 Bucket</td>
                  <td className="px-4 py-2">Connected</td>
                  <td className="px-4 py-2">5 minutes ago</td>
                  <td className="px-4 py-2">2.8 TB</td>
                </tr>
                <tr>
                  <td className="px-4 py-2">Analytics DB</td>
                  <td className="px-4 py-2">ClickHouse</td>
                  <td className="px-4 py-2">Connected</td>
                  <td className="px-4 py-2">1 minute ago</td>
                  <td className="px-4 py-2">800 GB</td>
                </tr>
              </tbody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Data Operations */}
      <Card>
        <CardHeader>
          <CardTitle>Data Operations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[200px] flex items-center justify-center text-muted-foreground">
            Data operations and management controls will be displayed here
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

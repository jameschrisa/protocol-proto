import { TrendsChart } from "../components/trends/trends-chart"
import { SmallLineChart } from "../components/trends/small-line-chart"

// Generate 12 months of data
const generateMonthlyData = (baseValue: number, variance: number) => {
  const months = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ]
  return months.map(month => ({
    month,
    value: Math.round(baseValue + (Math.random() - 0.5) * variance)
  }))
}

export default function TrendsPage() {
  // Generate realistic data
  const volumeData = generateMonthlyData(1500, 300) // Base: 1500, Variance: ±150
  const recoveryData = generateMonthlyData(92, 8)   // Base: 92, Variance: ±4

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Trends</h1>

      {/* Main chart */}
      <TrendsChart />

      {/* Small charts - Two cards per row with increased gap */}
      <div className="grid gap-8 md:grid-cols-2">
        <div className="w-full h-full">
          <SmallLineChart
            title="Total Flare Gas Volume"
            description="Million Standard Cubic Feet per Day"
            value={volumeData[volumeData.length - 1].value}
            unit=""
            data={volumeData}
          />
        </div>
        <div className="w-full h-full">
          <SmallLineChart
            title="Gas Recovery Performance"
            description="12 Month Trend"
            value={recoveryData[recoveryData.length - 1].value}
            unit="%"
            data={recoveryData}
          />
        </div>
      </div>
    </div>
  )
}

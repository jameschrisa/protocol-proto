import { MaintenanceTable } from "../components/compliance/maintenance-table"
import { MaintenanceCharts } from "../components/maintenance/maintenance-charts"
import { EquipmentStatusTable } from "../components/maintenance/equipment-status-table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card"
import { maintenanceData } from "../data/maintenance-data"

export default function FlareMaintenance() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Flare Maintenance</h1>

      {/* Maintenance Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Scheduled Maintenance</CardTitle>
            <CardDescription>Upcoming maintenance activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {maintenanceData.filter(m => m.status === 'pending').length}
            </div>
            <p className="text-xs text-muted-foreground">
              Pending maintenance tasks
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>In Progress</CardTitle>
            <CardDescription>Currently active maintenance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {maintenanceData.filter(m => m.status === 'in-progress').length}
            </div>
            <p className="text-xs text-muted-foreground">
              Ongoing maintenance activities
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Completed</CardTitle>
            <CardDescription>Recent maintenance history</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {maintenanceData.filter(m => m.status === 'completed').length}
            </div>
            <p className="text-xs text-muted-foreground">
              Completed maintenance tasks
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Maintenance Charts */}
      <Card>
        <CardHeader>
          <CardTitle>Maintenance Analytics</CardTitle>
          <CardDescription>
            Overview of maintenance activities and trends
          </CardDescription>
        </CardHeader>
        <CardContent>
          <MaintenanceCharts />
        </CardContent>
      </Card>

      {/* Maintenance Schedule */}
      <Card>
        <CardHeader>
          <CardTitle>Maintenance Schedule</CardTitle>
          <CardDescription>
            Detailed view of all maintenance activities
          </CardDescription>
        </CardHeader>
        <CardContent>
          <MaintenanceTable data={maintenanceData} />
        </CardContent>
      </Card>

      {/* Equipment Status */}
      <Card>
        <CardHeader>
          <CardTitle>Equipment Status</CardTitle>
          <CardDescription>
            Current status of flare system components
          </CardDescription>
        </CardHeader>
        <CardContent>
          <EquipmentStatusTable />
        </CardContent>
      </Card>
    </div>
  )
}

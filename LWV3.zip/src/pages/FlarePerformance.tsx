import { FlarePieCharts } from "../components/flare-performance/flare-pie-charts"
import { FlareTable } from "../components/flare-performance/flare-table"
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card"
import { flareData } from "../data/flare-performance-data"

export default function FlarePerformancePage() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Flare Performance</h1>
      
      {/* Charts */}
      <FlarePieCharts />

      {/* Table */}
      <Card>
        <CardHeader>
          <CardTitle>Flare System Details</CardTitle>
        </CardHeader>
        <CardContent>
          <FlareTable data={flareData} />
        </CardContent>
      </Card>
    </div>
  )
}

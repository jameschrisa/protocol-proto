import { HelpCircle, Book, MessageSquare, Mail, Phone, FileText } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card"
import { Button } from "../components/ui/button"

const resources = [
  {
    title: "Documentation",
    description: "Browse our comprehensive guides and API documentation",
    icon: Book,
    link: "#"
  },
  {
    title: "Live Chat",
    description: "Chat with our support team in real-time",
    icon: MessageSquare,
    link: "#"
  },
  {
    title: "Email Support",
    description: "Send us a detailed message about your issue",
    icon: Mail,
    link: "mailto:support@example.com"
  },
  {
    title: "Phone Support",
    description: "Call us directly for urgent matters",
    icon: Phone,
    link: "tel:+1234567890"
  },
  {
    title: "Knowledge Base",
    description: "Find answers to common questions",
    icon: FileText,
    link: "#"
  }
]

export default function Support() {
  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <HelpCircle className="h-8 w-8 text-blue-600" strokeWidth={1.5} />
        <h1 className="text-3xl font-bold">Support Center</h1>
      </div>

      {/* Quick Help */}
      <Card>
        <CardHeader>
          <CardTitle>How can we help you today?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {resources.map((resource) => (
              <Card key={resource.title}>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <resource.icon className="h-5 w-5 text-blue-500" />
                      <h3 className="font-semibold">{resource.title}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {resource.description}
                    </p>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => window.location.href = resource.link}
                    >
                      Access {resource.title}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* FAQ Section */}
      <Card>
        <CardHeader>
          <CardTitle>Frequently Asked Questions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="border-b pb-4">
              <h3 className="font-semibold mb-2">How do I get started?</h3>
              <p className="text-sm text-muted-foreground">
                Check our comprehensive getting started guide in the documentation section.
              </p>
            </div>
            <div className="border-b pb-4">
              <h3 className="font-semibold mb-2">What are the system requirements?</h3>
              <p className="text-sm text-muted-foreground">
                Our system is cloud-based and works with any modern web browser.
              </p>
            </div>
            <div className="border-b pb-4">
              <h3 className="font-semibold mb-2">How do I reset my password?</h3>
              <p className="text-sm text-muted-foreground">
                Use the "Forgot Password" link on the login page to reset your credentials.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Contact Form */}
      <Card>
        <CardHeader>
          <CardTitle>Contact Support Team</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[200px] flex items-center justify-center text-muted-foreground">
            Contact form will be implemented here
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

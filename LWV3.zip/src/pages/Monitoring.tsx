import { Activity, AlertCircle, CheckCircle, Clock } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card"
import { Badge } from "../components/ui/badge"

const systems = [
  {
    name: "Primary System",
    status: "Operational",
    uptime: "99.9%",
    lastCheck: "2 minutes ago",
    badge: "default"
  },
  {
    name: "Backup System",
    status: "Standby",
    uptime: "100%",
    lastCheck: "1 minute ago",
    badge: "secondary"
  },
  {
    name: "Data Processing",
    status: "Operational",
    uptime: "99.7%",
    lastCheck: "Just now",
    badge: "default"
  },
  {
    name: "Storage System",
    status: "Operational",
    uptime: "99.8%",
    lastCheck: "3 minutes ago",
    badge: "default"
  }
]

export default function Monitoring() {
  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <Activity className="h-8 w-8 text-blue-600" strokeWidth={1.5} />
        <h1 className="text-3xl font-bold">System Monitoring</h1>
      </div>

      {/* Status Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {systems.map((system) => (
          <Card key={system.name}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {system.name}
              </CardTitle>
              <Badge variant={system.badge as "default" | "secondary"}>
                {system.status}
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Uptime: {system.uptime}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-gray-500" />
                  <span className="text-sm">Last check: {system.lastCheck}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Real-time Monitoring */}
      <Card>
        <CardHeader>
          <CardTitle>Real-time System Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[400px] flex items-center justify-center text-muted-foreground">
            Real-time monitoring dashboard will be displayed here
          </div>
        </CardContent>
      </Card>

      {/* Active Alerts */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Active Alerts</CardTitle>
          <AlertCircle className="h-5 w-5 text-yellow-500" />
        </CardHeader>
        <CardContent>
          <div className="h-[200px] flex items-center justify-center text-muted-foreground">
            Active system alerts will be displayed here
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

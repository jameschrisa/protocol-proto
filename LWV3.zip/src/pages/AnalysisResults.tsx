import { useNavigate } from "react-router-dom"
import { FlareAnalysisRadial } from "../components/ui/radial-chart"
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card"
import { Button } from "../components/ui/button"
import { ArrowLeft, Gauge, CheckCircle2, AlertTriangle } from "lucide-react"

const metrics = [
  {
    title: "Overall Score",
    value: "95.4%",
    description: "Above industry average",
    icon: Gauge,
    color: "text-blue-500",
    trend: "up"
  },
  {
    title: "Compliance Status",
    value: "Compliant",
    description: "All parameters within limits",
    icon: CheckCircle2,
    color: "text-green-500",
    trend: "neutral"
  },
  {
    title: "Areas of Improvement",
    value: "2",
    description: "Minor optimizations needed",
    icon: AlertTriangle,
    color: "text-yellow-500",
    trend: "neutral"
  }
]

export default function AnalysisResults() {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Analysis Results</h1>
            <p className="text-muted-foreground">
              Comprehensive analysis of flare system performance metrics
            </p>
          </div>
          <Button 
            variant="outline" 
            onClick={() => navigate('/')}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Return to Dashboard
          </Button>
        </div>

        {/* Summary Metrics */}
        <div className="grid gap-4 md:grid-cols-3">
          {metrics.map((metric) => (
            <Card key={metric.title} className="bg-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {metric.title}
                </CardTitle>
                <metric.icon className={`h-4 w-4 ${metric.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metric.value}</div>
                <p className="text-xs text-muted-foreground">
                  {metric.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Radial Chart */}
        <Card className="bg-card">
          <CardHeader>
            <CardTitle>Performance Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <FlareAnalysisRadial />
          </CardContent>
        </Card>

        {/* Recommendations */}
        <Card className="bg-card">
          <CardHeader>
            <CardTitle>Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <div className="mt-1 h-2 w-2 rounded-full bg-blue-500 flex-shrink-0" />
                <div>
                  <p className="font-medium">Optimize Flow Rate Utilization</p>
                  <p className="text-sm text-muted-foreground">
                    Current performance is 92% against target of 95%. Consider adjusting flow control parameters during peak hours.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="mt-1 h-2 w-2 rounded-full bg-blue-500 flex-shrink-0" />
                <div>
                  <p className="font-medium">Enhance Emissions Compliance</p>
                  <p className="text-sm text-muted-foreground">
                    While within acceptable range, emissions compliance can be improved from 94% to meet target of 95%.
                  </p>
                </div>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

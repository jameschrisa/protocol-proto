import { FileText, Book, Code, Terminal, GitBranch, Package } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card"

const sections = [
  {
    title: "Getting Started",
    description: "Learn the basics and get up and running quickly",
    icon: Book,
    items: [
      "System Requirements",
      "Installation Guide",
      "Quick Start Tutorial",
      "Basic Concepts"
    ]
  },
  {
    title: "API Reference",
    description: "Detailed API documentation and examples",
    icon: Code,
    items: [
      "REST API Endpoints",
      "Authentication",
      "Rate Limits",
      "Response Formats"
    ]
  },
  {
    title: "CLI Documentation",
    description: "Command-line interface usage and commands",
    icon: Terminal,
    items: [
      "Installation",
      "Basic Commands",
      "Configuration",
      "Advanced Usage"
    ]
  },
  {
    title: "Integration Guides",
    description: "Connect and integrate with other systems",
    icon: GitBranch,
    items: [
      "Third-party Integrations",
      "Webhooks",
      "SSO Setup",
      "Data Import/Export"
    ]
  },
  {
    title: "Components",
    description: "UI components and usage guidelines",
    icon: Package,
    items: [
      "Component Library",
      "Styling Guide",
      "Best Practices",
      "Examples"
    ]
  }
]

export default function Documentation() {
  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <FileText className="h-8 w-8 text-blue-600" strokeWidth={1.5} />
        <h1 className="text-3xl font-bold">Documentation</h1>
      </div>

      {/* Quick Links */}
      <Card>
        <CardHeader>
          <CardTitle>Documentation Sections</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {sections.map((section) => (
              <Card key={section.title} className="cursor-pointer hover:bg-accent">
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <section.icon className="h-5 w-5 text-blue-500" />
                      <h3 className="font-semibold">{section.title}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {section.description}
                    </p>
                    <ul className="space-y-2">
                      {section.items.map((item) => (
                        <li key={item} className="text-sm text-muted-foreground hover:text-foreground">
                          • {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Search Documentation */}
      <Card>
        <CardHeader>
          <CardTitle>Search Documentation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[100px] flex items-center justify-center text-muted-foreground">
            Documentation search functionality will be implemented here
          </div>
        </CardContent>
      </Card>

      {/* Recent Updates */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Documentation Updates</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="border-b pb-4">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold">API Authentication Updates</h3>
                <span className="text-sm text-muted-foreground">2 days ago</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Updated OAuth2 implementation details and added new examples
              </p>
            </div>
            <div className="border-b pb-4">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold">New Integration Guide</h3>
                <span className="text-sm text-muted-foreground">5 days ago</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Added documentation for Webhook integration and event handling
              </p>
            </div>
            <div className="pb-4">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold">CLI Command Updates</h3>
                <span className="text-sm text-muted-foreground">1 week ago</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Added new CLI commands for data export and backup operations
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

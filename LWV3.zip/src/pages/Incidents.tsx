import { AlertTriangle, Clock, CheckCircle2, AlertCircle, Filter } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card"
import { Badge } from "../components/ui/badge"
import { Button } from "../components/ui/button"

const incidents = [
  {
    id: "INC-001",
    title: "Database Connection Timeout",
    status: "Active",
    priority: "High",
    timeReported: "10 minutes ago",
    affectedSystem: "Database",
    badge: "destructive"
  },
  {
    id: "INC-002",
    title: "API Response Latency",
    status: "Investigating",
    priority: "Medium",
    timeReported: "25 minutes ago",
    affectedSystem: "API Gateway",
    badge: "secondary"
  },
  {
    id: "INC-003",
    title: "Storage Space Warning",
    status: "Resolved",
    priority: "Low",
    timeReported: "1 hour ago",
    affectedSystem: "Storage",
    badge: "outline"
  }
]

const stats = [
  {
    title: "Active Incidents",
    value: "2",
    icon: AlertCircle,
    color: "text-red-500"
  },
  {
    title: "Resolved Today",
    value: "5",
    icon: CheckCircle2,
    color: "text-green-500"
  },
  {
    title: "Average Resolution Time",
    value: "45m",
    icon: Clock,
    color: "text-blue-500"
  }
]

export default function Incidents() {
  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <AlertTriangle className="h-8 w-8 text-blue-600" strokeWidth={1.5} />
        <h1 className="text-3xl font-bold">Incident Management</h1>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.title}
              </CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Incidents List */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Current Incidents</CardTitle>
          <Button variant="outline" size="sm" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filter
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {incidents.map((incident) => (
              <Card key={incident.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm text-muted-foreground">
                        {incident.id}
                      </span>
                      <Badge variant={incident.badge as "destructive" | "secondary" | "outline"}>
                        {incident.status}
                      </Badge>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {incident.timeReported}
                    </span>
                  </div>
                  <h3 className="font-semibold mb-2">{incident.title}</h3>
                  <div className="flex gap-4 text-sm text-muted-foreground">
                    <span>Priority: {incident.priority}</span>
                    <span>System: {incident.affectedSystem}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Incident Timeline */}
      <Card>
        <CardHeader>
          <CardTitle>Incident Timeline</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center text-muted-foreground">
            Incident timeline visualization will be displayed here
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

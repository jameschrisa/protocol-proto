export interface IncidentRecord {
  id: string
  date: string
  type: 'operational' | 'mechanical' | 'control' | 'environmental'
  severity: 'critical' | 'high' | 'medium' | 'low'
  description: string
  status: 'resolved' | 'investigating' | 'mitigated'
  duration: number // in minutes
  downtimeCause?: 'maintenance' | 'mechanical failure' | 'electrical issue'
  impact: string
  resolution?: string
}

// Helper function to generate incident descriptions
const getDescription = (type: string) => {
  const descriptions = {
    operational: [
      "Unexpected flame-out during high wind conditions",
      "Steam flow instability",
      "Multiple pilot failures",
      "Emergency shutdown triggered",
      "Minor flame stability fluctuation"
    ],
    mechanical: [
      "Steam injection system pressure fluctuation",
      "Knockout drum level sensor malfunction",
      "Pilot gas pressure drop",
      "Main flare tip damage",
      "Molecular seal failure"
    ],
    control: [
      "Control system communication failure",
      "Flow meter calibration drift",
      "Temperature sensor deviation",
      "Data logging interruption",
      "Ignition system fault"
    ],
    environmental: [
      "Elevated NOx emissions detected",
      "Smoke visibility exceeds threshold",
      "VOC emissions spike",
      "Heat radiation above normal",
      "Noise level exceedance"
    ]
  }
  return descriptions[type as keyof typeof descriptions][
    Math.floor(Math.random() * descriptions[type as keyof typeof descriptions].length)
  ]
}

// Generate 12 months of incident data
export const incidentsData: IncidentRecord[] = Array.from({ length: 240 }, (_, index) => {
  const types = ['operational', 'mechanical', 'control', 'environmental']
  const severities = ['critical', 'high', 'medium', 'low']
  const downtimeCauses = ['maintenance', 'mechanical failure', 'electrical issue']
  const statuses = ['resolved', 'investigating', 'mitigated']
  
  // Generate date within the last 12 months
  const date = new Date(2023, 2, 1) // Start from March 2023
  date.setDate(date.getDate() + Math.floor(index / 20) * 30 + (index % 20)) // Spread incidents across months

  const type = types[Math.floor(Math.random() * types.length)] as IncidentRecord['type']
  const severity = severities[Math.floor(Math.random() * severities.length)] as IncidentRecord['severity']
  const downtimeCause = downtimeCauses[Math.floor(Math.random() * downtimeCauses.length)] as IncidentRecord['downtimeCause']

  return {
    id: `i${String(index + 1).padStart(3, '0')}`,
    date: date.toISOString().split('T')[0],
    type,
    severity,
    description: getDescription(type),
    status: statuses[Math.floor(Math.random() * statuses.length)] as IncidentRecord['status'],
    duration: Math.floor(Math.random() * 240) + 30, // 30-270 minutes
    downtimeCause,
    impact: severity === 'critical' ? 'Major system impact' :
           severity === 'high' ? 'Significant disruption' :
           severity === 'medium' ? 'Moderate impact' : 'Minor impact',
    resolution: Math.random() > 0.2 ? 'Issue resolved and documented' : undefined // 80% resolved
  }
}).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

export const incidentStatusColors = {
  resolved: "text-green-500",
  investigating: "text-yellow-500",
  mitigated: "text-blue-500"
}

export const incidentTypeColors = {
  operational: "bg-blue-100 text-blue-800",
  mechanical: "bg-orange-100 text-orange-800",
  control: "bg-purple-100 text-purple-800",
  environmental: "bg-green-100 text-green-800"
}

export const incidentSeverityColors = {
  critical: "text-red-600 font-bold",
  high: "text-red-500",
  medium: "text-yellow-500",
  low: "text-green-500"
}

export type TimeScale = 'daily' | 'weekly' | 'monthly'

export interface IncidentTimeData {
  date: string
  operational: number
  mechanical: number
  control: number
  environmental: number
}

export const categoryColors = {
  operational: "hsl(var(--chart-1))",
  mechanical: "hsl(var(--chart-2))",
  control: "hsl(var(--chart-3))",
  environmental: "hsl(var(--chart-4))"
}

export function aggregateDataByTimeScale(data: IncidentRecord[], scale: TimeScale): IncidentTimeData[] {
  // Group incidents by time period and count by type
  const aggregated = data.reduce((acc: { [key: string]: IncidentTimeData }, incident) => {
    const date = new Date(incident.date)
    let period: string

    switch (scale) {
      case 'daily':
        period = date.toISOString().split('T')[0]
        break
      case 'weekly':
        const week = Math.floor(date.getDate() / 7) + 1
        period = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-W${week}`
        break
      case 'monthly':
      default:
        period = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}`
    }

    if (!acc[period]) {
      acc[period] = {
        date: period,
        operational: 0,
        mechanical: 0,
        control: 0,
        environmental: 0
      }
    }

    acc[period][incident.type as keyof Omit<IncidentTimeData, 'date'>]++
    return acc
  }, {})

  return Object.values(aggregated).sort((a, b) => a.date.localeCompare(b.date))
}
